var a = 10;
if (a%2==0)
{   
    document.write("Number Is Even")
}
else
{
    document.write("Number Is Odd")
}