function red()
{   
    document.write("<body bgcolor = red></body>")
}
function green()
{   
    document.write("<body bgcolor = green></body>")
}
function yellow()
{   
    document.write("<body bgcolor = yellow></body>")
}
function alertbox()
{
    alert("I Am A Alert Box")  
}