var a = -1,b = 1,c=0,n=10;
for(i=0;i<n;i++)
{   
    c = a + b;  
    document.write("<h1>")
    document.write(c+"<br>");
    a = b;
    b = c;
}