var a=10,b=20,c=30;
if(a > b && b > c)
{
    var largest = a;
}
else if(b > a && a > c)
{
    var largest = b;
}
else
{
    var largest = c;
}
document.write("<h1>Largest Is "+largest)