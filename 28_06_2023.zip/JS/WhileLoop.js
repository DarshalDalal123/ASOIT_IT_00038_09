var a = 1;
while( a < 10 )
{   
    document.write("<h1>")
    document.write(a+"<br>");
    a++;
}