//Arithmetic
let n1=50,n2=30;
var sum = n1 + n2;
var mul = n1 * n2;
var sub = n1 - n2;
var div = n1 / n2;
var mod = n1 % n2;
var Exponentiation = 5**2; 
document.write("<h1>Arithmetic Operators")
document.write("<br/>Sum:",sum+"<br/>Mul:",mul+"<br/>Sub:",sub+"<br/>Div:",div+"<br/>Modulo:",mod+"<br/>Post Inc:",n1++ +"<br/>Post Dec:",n1--+"<br/>Pre Inc:",++n1+"<br/>Pre Dec:",--n1+"<br/>Exp:",Exponentiation)
//Assignment
var x = 10,y=10,z=10,a=10,b=10,c=10;
x += 50;
y -= 50;
z *= 50;
a /= 50;
b %= 50;
c **= 50;
document.write("<h1>Assignment Operators")
document.write("<br/>+=:",x+"<br/>-=:",y+"<br/>*=",z+"<br/>/=:",a+"<br/>%=:",b+"<br/>**=:",c)
var n13=10,n22=10;
// Comparison Operator
// == equal to value only.
if(n13==n22){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}

// === equal to value & type.
if(n13===n22){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}
document.write("<h1>Type Operators")
class Rectangle{
    constructor(height,width)
    {   
        this.height = height
        this.width = width
    }
}
var R = new Rectangle(10,20)
document.write("<br>")
document.write(R instanceof Rectangle)
document.write("<br>")
document.write(typeof "Darshal")